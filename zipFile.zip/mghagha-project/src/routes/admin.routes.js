const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const { requireRole } = require('../middleware/auth');

router.use(requireRole('admin'));

router.get('/dashboard', adminController.dashboard);

router.get('/vendor-applications', adminController.listVendorApplications);
router.get('/vendor-applications/:id/id-card/:side', adminController.viewIdCardImage);
router.post('/vendor-applications/:id/approve', adminController.approveVendorApplication);
router.post('/vendor-applications/:id/reject', adminController.rejectVendorApplication);

router.get('/orders', adminController.listOrders);
router.get('/orders/:id', adminController.viewOrder);

router.get('/reviews', adminController.listReviews);
router.post('/reviews/:id/hide', adminController.hideReview);
router.post('/reviews/:id/unhide', adminController.unhideReview);

router.get('/stores', adminController.listStores);
router.post('/stores/:id/suspend', adminController.suspendStore);
router.post('/stores/:id/activate', adminController.activateStore);
router.get('/stores/:id/products', adminController.listStoreProducts);
router.post('/stores/:id/products/:productId/toggle-status', adminController.toggleStoreProduct);
router.post('/stores/:id/products/:productId/delete', adminController.deleteStoreProduct);

router.get('/users', adminController.listUsers);
router.post('/users/:id/suspend', adminController.suspendUser);
router.post('/users/:id/activate', adminController.activateUser);

router.get('/banners', adminController.listBanners);
router.post('/banners/upload', adminController.uploadBanner);
router.post('/banners/:id/delete', adminController.deleteBanner);
router.post('/banners/:id/toggle', adminController.toggleBanner);

router.get('/flagged-chats', adminController.listFlaggedChats);
router.get('/flagged-chats/:id', adminController.viewFlaggedChat);
router.post('/flagged-chats/:id/unflag', adminController.unflagChat);

module.exports = router;
